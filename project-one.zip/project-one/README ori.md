This repository is mainly created for Software Project courses. Basically after learning React through this course, the main objective is to upload the basic projects that I have done.
These project are made with the help of the following video:
https://youtu.be/bMknfKXIFA8
