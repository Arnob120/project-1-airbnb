This is a simple React project. I have tried this myself by watching videos of freecodecamp youtube channel.
Click the link below to view it.  
https://glittery-llama-b5fb9d.netlify.app/

![](../02-AirBnb-React-Project/src/images/airbnb.PNG)